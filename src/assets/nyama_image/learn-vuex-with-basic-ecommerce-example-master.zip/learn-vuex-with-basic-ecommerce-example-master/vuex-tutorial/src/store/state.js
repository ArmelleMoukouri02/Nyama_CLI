export default {
    notifications: []
}