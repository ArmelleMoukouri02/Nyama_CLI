export default {
    products: [],
    product: null,
}